
public class criaFiguras {

}
