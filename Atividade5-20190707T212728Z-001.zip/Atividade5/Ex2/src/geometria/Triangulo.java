package geometria;

public class Triangulo extends Poligono {

	public Triangulo() {
		super(3);
	}

	public Triangulo(float l1, float l2, float l3) {
		super(new float[] { l1, l2, l3 });
	}

	@Override
	public float calculaArea() {
		float p = calculaPerimetro() / 2;
		return (float) (Math.sqrt(p * (p - lados[1]) * (p - lados[2]) * (p - lados[3])));
	}
}
