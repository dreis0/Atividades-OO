package geometria;

public class Circulo extends FiguraPlana {

	private float raio;

	public Circulo(float r) {
		super.setTipo("Circulo");
		raio = r;
	}

	public Circulo() {
		super.setTipo("Circulo");
		raio = (float) Math.random();
	}

	public float getRaio() {
		return raio;
	}

	public void setRaio(float raio) {
		this.raio = raio;
	}

	@Override
	public float calculaArea() {
		return (float) (Math.PI * Math.pow(raio, 2));
	}

	@Override
	public float calculaPerimetro() {
		return (float) (Math.PI * raio * 2);
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}
}
